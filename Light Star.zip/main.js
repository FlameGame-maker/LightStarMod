/*
BUILD INFO:
  dir: dev
  target: main.js
  files: 9
*/



// file: header.js

IMPORT("BackpackAPI");
IMPORT("GuideAPI");
IMPORT("DungeonAPI");
IMPORT("ToolType");




// file: other.js

IDRegistry.genItemID("Avoska");
Item.createItem("Avoska", "String Bag", {name: "Avoska", meta: 0}, {stack: 1});
BackpackRegistry.register(ItemID.Avoska, {
    slots: 5,
    slotsCenter: true,
    inRow: 1
});
Recipes.addShaped({id: ItemID.Avoska, count: 1, data: 0}, [
		" a ",
		"a a",
		"aaa"
	], ['a', 287, 0]);
//одеваемые
IDRegistry.genItemID("Remen");
Item.createArmorItem("Remen", "Strap", {name: "Remen"}, {type: "leggings", armor: 6, durability: 5556, texture: "armor/Snachok_1.png", isTech:false}); 
Recipes.addShaped({id: ItemID.Remen, count: 1, data: 0}, [
		" a ",
		"aba",
		"aba"
	], ['a', 334, 0, 'b', 266, 0]);
//электроника
IDRegistry.genItemID("Acam");
Item.createItem("Acam", "Accumulator", {name: "Acamulator", meta: 0}, {stack: 64});
Recipes.addShaped({id: ItemID.Acam, count: 1, data: 0}, [
		"aba",
		"cbc",
		"bbb"
	], ['a', 356, 0, 'b', 265, 0, 'c', 404, 0]);
IDRegistry.genItemID("Plast");
Item.createItem("Plast", "Lead Plate", {name: "Plast", meta: 0}, {stack: 64});
IDRegistry.genItemID("Battarey");
Item.createItem("Battarey", "Battery: Planet-2", {name: "Battery", meta: 0}, {stack: 64});
Recipes.addShaped({id: ItemID.Battarey, count: 1, data: 0}, [
		"a a",
		" b ",
		" b "
	], ['a', ItemID.Plast, 0, 'b', 265, 0]);
Callback.addCallback('ItemUse', function (coords, item, block) {
if(Player.getCarriedItem().id==ItemID.Acam){
Player.setCarriedItem(item.count - 1);
let coords = Entity.getPosition(Player.get());
World.drop(coords.x, coords.y, coords.z, ItemID.Plast, 2);
}});




// file: Decor/block.js

IDRegistry.genBlockID("ApparatOne");
Block.createBlockWithRotation("ApparatOne", [{name: "Low Block Of The Unit", texture: [["side", 0], ["side", 0], ["side", 0], ["front", 0], ["side", 0], ["side", 0]], inCreative: true}]);
ToolAPI.registerBlockMaterial(BlockID.ApparatOne, "stone", 2, true);
Block.setDestroyLevel("ApparatOne", 2);
IDRegistry.genBlockID("ApparatTwo");
Block.createBlockWithRotation("ApparatTwo", [{name: "High Block Of The Unit", texture: [["side", 0], ["side", 0], ["side", 0], ["front", 1], ["side", 0], ["side", 0]], inCreative: true}]);
ToolAPI.registerBlockMaterial(BlockID.ApparatTwo, "stone", 2, true);
Block.setDestroyLevel("ApparatTwo", 2);

IDRegistry.genBlockID("SneckOne");
Block.createBlockWithRotation("SneckOne", [{name: "Low Block Of The Sneck Apparatus", texture: [["side", 1], ["side", 1], ["side", 1], ["sneck", 0], ["side", 1], ["side", 1]], inCreative: true}]);
ToolAPI.registerBlockMaterial(BlockID.SneckOne, "stone", 2, true);
Block.setDestroyLevel("SneckOne", 2);
IDRegistry.genBlockID("SneckTwo");
Block.createBlockWithRotation("SneckTwo", [{name: "High Block Of The Sneck Apparatus", texture: [["side", 1], ["side", 1], ["side", 1], ["sneck", 1], ["side", 1], ["side", 1]], inCreative: true}]);
ToolAPI.registerBlockMaterial(BlockID.SneckTwo, "stone", 2, true);
Block.setDestroyLevel("SneckTwo", 2);

IDRegistry.genBlockID("SintezOne");
Block.createBlockWithRotation("SintezOne", [{name: "Left Block Of The Synthesizer", texture: [["side", 2], ["sintez", 0], ["side", 2], ["side", 2], ["side", 2], ["side", 2]], inCreative: true}]);
ToolAPI.registerBlockMaterial(BlockID.SintezOne, "stone", 2, true);
Block.setDestroyLevel("SintezOne", 2);
IDRegistry.genBlockID("SintezTwo");
Block.createBlockWithRotation("SintezTwo", [{name: "Right Block Of The Synthesizer", texture: [["side", 2], ["sintez", 1], ["side", 2], ["side", 2], ["side", 2], ["side", 2]], inCreative: true}]);
ToolAPI.registerBlockMaterial(BlockID.SintezTwo, "stone", 2, true);
Block.setDestroyLevel("SintezTwo", 2);

IDRegistry.genBlockID("Baraban");
Block.createBlockWithRotation("Baraban", [{name: "The drum", texture: [["baraban", 0], ["baraban", 0], ["side", 3], ["side", 3], ["side", 3], ["side", 3]], inCreative: true}]);
ToolAPI.registerBlockMaterial(BlockID.Baraban, "stone", 2, true);
Block.setDestroyLevel("Baraban", 2);




// file: Game/game.js

IDRegistry.genItemID("Game");
Item.createItem("Game", "Game", {name: "Game", meta: 0}, {stack: 64});
Recipes.addShaped({id: ItemID.Game, count: 1, data: 0}, [
		"aba",
		"cac",
		"aaa"
	], ['b', ItemID.Battarey, 0, 'a', 265, 0, 'c', 331, 0]);
GuideAPI.registerGuide("Game", { 
item: ItemID.Game, 
debug: false, 
textures: { 
background: "test", 
nextLink: "next_page", 
preLink: "pre_page", 
close: "btn_close", 
}, 

pages: {
	
            "default": {
                nextLink: "default",
                left: {
                    controller: PageControllers.BASIC_PAGE,                  
                    elements: [
                        {text: "Ваша задача состоит в том, чтобы отходить в разные стороны и ловить яйца курить, орентируясь на удачу. Игра началась!", size: 25, link: "first"},
                    ]
                },
                
                right: {
                    controller: PageControllers.BASIC_PAGE,
                    elements: [
                         {text: "Отойти вправо", size: 35, link: "turn1"},
                         {text: "Отойти влево", size: 35, link: "over"},
                    ]
                }
            },
            "over": {
                nextLink: "default",
                left: {
                    controller: PageControllers.ITEM_PAGE,
                    items: [
                        {id: ItemID.Over}
                    ],
                    elements: [
                        {text: "Начать заново?", size: 25, link: "default"},
                    ]
                },
                
                right: {
                    controller: PageControllers.BASIC_PAGE,
                    elements: [
                         {text: ".", size: 1},
                    ]
                }
            },
            "turn1": {
            	preLink: "default",
                nextLink: "left1",
                left: {
                    controller: PageControllers.ITEM_PAGE,
                    items: [
                        {id: ItemID.RightBG}
                    ],
                    elements: [
                       {text: "Поднять корзинку", size: 35, link: "over"},
                       {text: "Поднять корзинку", size: 35, link: "beta"},
                    ]
                },
                
                right: {
                    controller: PageControllers.BASIC_PAGE,
                    elements: [
                        {text: ".", size: 1},
                    ]
                }
            },
            "beta": {
            	preLink: "default",
                nextLink: "default",
                left: {
                    controller: PageControllers.BASIC_PAGE,                  
                    elements: [
                       {text: "Кажется, приставка заискрилась и дымится. Видимо, это конец беты(", size: 25},
                    ]
                },
                
                right: {
                    controller: PageControllers.BASIC_PAGE,
                    elements: [
                        {text: ".", size: 1},
                    ]
                }
            },
}
});




// file: Game/images.js

IDRegistry.genItemID("Start");
Item.createItem("Start", "Start Image", {name: "start", meta: 0}, {stack: 64});
IDRegistry.genItemID("Over");
Item.createItem("Over", "Over Image", {name: "over", meta: 0}, {stack: 64});
IDRegistry.genItemID("RightBG");
Item.createItem("RightBG", "Right Background Image", {name: "background_right", meta: 0}, {stack: 64});
IDRegistry.genItemID("LeftBG");
Item.createItem("LeftBG", "Left Background Image", {name: "background_left", meta: 0}, {stack: 64});




// file: guns.js

IMPORT("ShootLib", "ShootLib");

var ShotType = ShootLib.ShotType;
var ButtonType = ShootLib.ButtonType;

ShootLib.init({
    crosshairGUI:{
        bitmap:{
            coords:{
                width:2048,
                height:512
            },
            size:{
                width:4000,
                height:1000
            }
        }
    }
});
ShootLib.addGun({
    id:"Ak47",
    name:"AK-47",
    ammo:"Akpatron",
    accuracy:5,
    recoil:3,
    rate:6,
    texture:{
        name:"Ak47",
        meta:0
    },
    shotType:ShotType.NORMAL,
    buttonType:ButtonType.TOUCH,
    bullet:{
        speed:10,
        count:30,
        damage:20
    },
    fov:{
        level:10
    },
    sounds:{
        shot:"ShootAK.ogg",
        empty:"EmptyAK.ogg",
        reload:"ReloadAK.ogg"
    }
});
ShootLib.addGun({
    id:"Ppsh",
    name:"SGS",
    ammo:"Ppshpatron",
    accuracy:5,
    recoil:1,
    rate:6,
    texture:{
        name:"Ppsh",
        meta:0
    },
    shotType:ShotType.NORMAL,
    buttonType:ButtonType.TOUCH,
    bullet:{
        speed:20,
        count:71,
        damage:30
    },
    fov:{
        level:10
    },
    sounds:{
        shot:"ShootAK.ogg",
        empty:"EmptyAK.ogg",
        reload:"ReloadAK.ogg"
    }
});
ShootLib.addAmmos([{
    id:"Akpatron",
    name:"AK Bullets",
    texture:{
        name:"akpatron",
        meta:0
    }
},{
    id:"Ppshpatron",
    name:"SGS Bullets",
    texture:{
        name:"Ppshpatron",
        meta:0
    }
},]);
IDRegistry.genItemID("Ak47")

Recipes.addShaped({id: ItemID.Ak47, count: 1, data: 0}, [
	"abb",
	" cb",
	" aa"
], ['a', 265 , 0, 'b', 5, 0, 'c', 331, 0]);
IDRegistry.genItemID("Ppsh")

Recipes.addShaped({id: ItemID.Ppsh, count: 1, data: 0}, [
	"abb",
	"aac",
	" aa"
], ['a', 265 , 0, 'b', 356, 0, 'c', ItemID.Plast, 0]);
IDRegistry.genItemID("Akpatron")

Recipes.addShaped({id: ItemID.Akpatron, count: 1, data: 0}, [
	"",
	"cb",
	"ac"
], ['a', 265 , 0, 'b', 331, 0, 'c', 289, 0]);
IDRegistry.genItemID("Ppshpatron")

Recipes.addShaped({id: ItemID.Ppshpatron, count: 1, data: 0}, [
	"bbb",
	"cac",
	"bbb"
], ['a', 265 , 0, 'b', 331, 0, 'c', 289, 0]);




// file: eatble.js

IDRegistry.genItemID("Mars");
Item.createFoodItem("Mars", "Bar Mars", {name: "Mars", meta: 0},{isTech:false,stack: 64,food: 2});
Callback.addCallback('ItemUse', function (coords, item, block) {
if(item.id == [371] && block.id == BlockID.SneckTwo){
Player.setCarriedItem(item.count - 1);
let coords = Entity.getPosition(Player.get());
World.drop(coords.x, coords.y, coords.z, ItemID.Mars, 1);
}});
IDRegistry.genItemID("Cola");
Item.createFoodItem("Cola", "Galss Of Coca-Cola", {name: "Gcola", meta: 0},{isTech:false,stack: 64,food: 2});
Recipes.addShaped({id: ItemID.Cola, count: 1, data: 0}, [
		"aaa",
		"aba",
		"aaa"
	], ['b', ItemID.Water, 0, 'a', 353, 0]);
IDRegistry.genItemID("Water");
Item.createFoodItem("Water", "Glass Of Water", {name: "Gwater", meta: 0},{isTech:false,stack: 64,food: 1});
Callback.addCallback('ItemUse', function (coords, item, block) {
if(item.id == ItemID.Stakan && block.id == BlockID.ApparatTwo){
Player.setCarriedItem(item.count - 1);
let coords = Entity.getPosition(Player.get());
World.drop(coords.x, coords.y, coords.z, ItemID.Water, 1);
}});




// file: Decor/items.js

//выжигатель
IDRegistry.genItemID("Vijog");
Item.createItem("Vijog", "Burning Machine", {name: "vijog", meta: 0}, {stack: 64});
Recipes.addShaped({id: ItemID.Vijog, count: 1, data: 0}, [
		"  a",
		"aab",
		"cc"
	], ['a', 265, 0, 'b', 287, 0, 'c', ItemID.Battarey, 0]);
IDRegistry.genItemID("Doska");
Item.createItem("Doska", "Plank", {name: "doska", meta: 0}, {stack: 64});
Recipes.addShaped({id: ItemID.Doska, count: 1, data: 0}, [
		" a ",
		"aba",
		" a "
	], ['a', 334, 0, 'b', 5, 0]);
IDRegistry.genItemID("DoskaT");
Item.createItem("DoskaT", "Plank With Tank", {name: "doska", meta: 1}, {stack: 64});
Recipes.addShaped({id: ItemID.DoskaT, count: 1, data: 0}, [
		"ab",
		"",
		""
	], ['a', ItemID.Vijog, 0, 'b', ItemID.Doska, 0]);
IDRegistry.genItemID("DoskaS");
Item.createItem("DoskaS", "Plank With Star", {name: "doska", meta: 2}, {stack: 64});
Recipes.addShaped({id: ItemID.DoskaS, count: 1, data: 0}, [
		"a",
		"b",
		""
	], ['a', ItemID.Vijog, 0, 'b', ItemID.Doska, 0]);
IDRegistry.genItemID("DoskaH");
Item.createItem("DoskaH", "Plank With Sickle And Hammer", {name: "doska", meta: 3}, {stack: 64});
Recipes.addShaped({id: ItemID.DoskaH, count: 1, data: 0}, [
		"",
		"ab",
		""
	], ['a', ItemID.Vijog, 0, 'b', ItemID.Doska, 0]);
//символ
IDRegistry.genItemID("Serp");
Item.createItem("Serp", "Sickle", {name: "Serp", meta: 0}, {stack: 64});
IDRegistry.genItemID("Hamm");
Item.createItem("Hamm", "Hammer", {name: "Hammer", meta: 0}, {stack: 64});
ToolAPI.addToolMaterial("Ussr", {
     durability: 69,
     level: 4, 
     efficiency: 10, 
     damage: 7, 
     enchantability: 22
});
ToolAPI.setTool(ItemID.Serp, "Ussr", ToolType.hoe);
ToolAPI.setTool(ItemID.Hamm, "Ussr", ToolType.sword);
IDRegistry.genItemID("Snachok");
Item.createArmorItem("Snachok", "Pin", {name: "Snachok"}, {type: "chestplate", armor: 7, durability: 5556, texture: "armor/Snachok_0.png", isTech:false}); 
Recipes.addShaped({id: ItemID.Snachok, count: 1, data: 0}, [
		"aaa",
		"bac",
		" a "
	], ['a', 265, 0, 'b', ItemID.Serp, 0, 'c', ItemID.Hamm, 0]);
//стакан
IDRegistry.genItemID("Stakan");
Item.createItem("Stakan", "Glass", {name: "Gempty", meta: 0}, {stack: 64});
Recipes.addShaped({id: ItemID.Stakan, count: 1, data: 0}, [
		"a a",
		"a a",
		" a "
	], ['a', 20, 0]);




// file: translate.js

Translation.addTranslation("String Bag", {ru: "Авоська"});
Translation.addTranslation("Strap", {ru: "Ремень"});
Translation.addTranslation("Accumulator", {ru: "Аккумулятор"});
Translation.addTranslation("Lead Plate", {ru: "Свинцовая Пластина"});
Translation.addTranslation("Battery: Planet-2", {ru: "Батарейка: Планета-2"});
Translation.addTranslation("Low Block Of The Unit", {ru: "Нижний Блок Аппарата ГазВоды"});
Translation.addTranslation("High Block Of The Unit", {ru: "Верхний Блок Аппарата ГазВоды"});
Translation.addTranslation("Game", {ru: "Игровая Приставка"});
Translation.addTranslation("SGS", {ru: "ППШ"});
Translation.addTranslation("AK Bullets", {ru: "Патроны к АК"});
Translation.addTranslation("SGS Bullets", {ru: "Патроны к ППШ"});
Translation.addTranslation("Sickle", {ru: "Серп"});
Translation.addTranslation("Hammer", {ru: "Молот"});
Translation.addTranslation("Bar Mars", {ru: "Батончик Марс"});
Translation.addTranslation("Galss Of Coca-Cola", {ru: "Стакан Кока-Колы"});
Translation.addTranslation("Glass Of Water", {ru: "Стакан Газированной Воды"});
Translation.addTranslation("Burning Machine", {ru: "Выжигатель"});
Translation.addTranslation("Plank", {ru: "Доска"});
Translation.addTranslation("Plank With Sickle And Hammer", {ru: "Доска С Серпом И Молотом"});
Translation.addTranslation("Plank With Star", {ru: "Доска Со Звездой"});
Translation.addTranslation("Plank With Tank", {ru: "Доска С Танком"});
Translation.addTranslation("Glass", {ru: "Стакан"});
Translation.addTranslation("Pin", {ru: "Значок"});




