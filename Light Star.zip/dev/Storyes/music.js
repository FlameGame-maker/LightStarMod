IDRegistry.genItemID("StoryM");
Item.createItem("StoryM", "Musical Starology", {name: "story", meta: 0}, {stack: 64});

GuideAPI.registerGuide("StoryM", { 
item: ItemID.StoryM, 
debug: false, 
textures: { 
background: "test", 
nextLink: "next_page", 
preLink: "pre_page", 
close: "btn_close", 
}, 

pages: {
	
            "default": {
                nextLink: "default",
                left: {
                    controller: PageControllers.BASIC_PAGE,                  
                    elements: [
                        {text: "Увы, но это ещё не реализованный контент.", size: 25},
                    ]
                },
                
                right: {
                    controller: PageControllers.BASIC_PAGE,
                    elements: [
                         {text: "Можешь уйти.", size: 25},
                    ]
                }
            },