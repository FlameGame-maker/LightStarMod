IDRegistry.genItemID("Mars");
Item.createFoodItem("Mars", "Bar Mars", {name: "Mars", meta: 0},{isTech:false,stack: 64,food: 2});
Callback.addCallback('ItemUse', function (coords, item, block) {
if(item.id == [371] && block.id == BlockID.SneckTwo){
Player.setCarriedItem(item.count - 1);
let coords = Entity.getPosition(Player.get());
World.drop(coords.x, coords.y, coords.z, ItemID.Mars, 1);
}});
IDRegistry.genItemID("Cola");
Item.createFoodItem("Cola", "Galss Of Coca-Cola", {name: "Gcola", meta: 0},{isTech:false,stack: 64,food: 2});
Recipes.addShaped({id: ItemID.Cola, count: 1, data: 0}, [
		"aaa",
		"aba",
		"aaa"
	], ['b', ItemID.Water, 0, 'a', 353, 0]);
IDRegistry.genItemID("Water");
Item.createFoodItem("Water", "Glass Of Water", {name: "Gwater", meta: 0},{isTech:false,stack: 64,food: 1});
Callback.addCallback('ItemUse', function (coords, item, block) {
if(item.id == ItemID.Stakan && block.id == BlockID.ApparatTwo){
Player.setCarriedItem(item.count - 1);
let coords = Entity.getPosition(Player.get());
World.drop(coords.x, coords.y, coords.z, ItemID.Water, 1);
}});