IDRegistry.genItemID("Start");
Item.createItem("Start", "Start Image", {name: "start", meta: 0}, {stack: 64});
IDRegistry.genItemID("Over");
Item.createItem("Over", "Over Image", {name: "over", meta: 0}, {stack: 64});
IDRegistry.genItemID("RightBG");
Item.createItem("RightBG", "Right Background Image", {name: "background_right", meta: 0}, {stack: 64});
IDRegistry.genItemID("LeftBG");
Item.createItem("LeftBG", "Left Background Image", {name: "background_left", meta: 0}, {stack: 64});
