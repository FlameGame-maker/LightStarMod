IDRegistry.genItemID("Game");
Item.createItem("Game", "Game", {name: "Game", meta: 0}, {stack: 64});
Recipes.addShaped({id: ItemID.Game, count: 1, data: 0}, [
		"aba",
		"cac",
		"aaa"
	], ['b', ItemID.Battarey, 0, 'a', 265, 0, 'c', 331, 0]);
GuideAPI.registerGuide("Game", { 
item: ItemID.Game, 
debug: false, 
textures: { 
background: "test", 
nextLink: "next_page", 
preLink: "pre_page", 
close: "btn_close", 
}, 

pages: {
	
            "default": {
                nextLink: "default",
                left: {
                    controller: PageControllers.BASIC_PAGE,                  
                    elements: [
                        {text: "Ваша задача состоит в том, чтобы отходить в разные стороны и ловить яйца курить, орентируясь на удачу. Игра началась!", size: 25, link: "first"},
                    ]
                },
                
                right: {
                    controller: PageControllers.BASIC_PAGE,
                    elements: [
                         {text: "Отойти вправо", size: 35, link: "turn1"},
                         {text: "Отойти влево", size: 35, link: "over"},
                    ]
                }
            },
            "over": {
                nextLink: "default",
                left: {
                    controller: PageControllers.ITEM_PAGE,
                    items: [
                        {id: ItemID.Over}
                    ],
                    elements: [
                        {text: "Начать заново?", size: 25, link: "default"},
                    ]
                },
                
                right: {
                    controller: PageControllers.BASIC_PAGE,
                    elements: [
                         {text: ".", size: 1},
                    ]
                }
            },
            "turn1": {
            	preLink: "default",
                nextLink: "left1",
                left: {
                    controller: PageControllers.ITEM_PAGE,
                    items: [
                        {id: ItemID.RightBG}
                    ],
                    elements: [
                       {text: "Поднять корзинку", size: 35, link: "over"},
                       {text: "Поднять корзинку", size: 35, link: "beta"},
                    ]
                },
                
                right: {
                    controller: PageControllers.BASIC_PAGE,
                    elements: [
                        {text: ".", size: 1},
                    ]
                }
            },
            "beta": {
            	preLink: "default",
                nextLink: "default",
                left: {
                    controller: PageControllers.BASIC_PAGE,                  
                    elements: [
                       {text: "Кажется, приставка заискрилась и дымится. Видимо, это конец беты(", size: 25},
                    ]
                },
                
                right: {
                    controller: PageControllers.BASIC_PAGE,
                    elements: [
                        {text: ".", size: 1},
                    ]
                }
            },
}
});